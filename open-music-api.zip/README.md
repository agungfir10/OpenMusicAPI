# Open Music API

## Setup

```
git clone
```

```
npm install | npm i
```

```
npm run migrate up
```

```
npm run start-dev
```
