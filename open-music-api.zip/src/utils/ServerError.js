const ServerError = {
  status: 'error',
  message: 'Maaf, terjadi kegagalan pada server kami.',
};
module.exports = ServerError;
